void deps_scripts_init();
