	deps_scripts_init();

