void deps_parsgen_init();
