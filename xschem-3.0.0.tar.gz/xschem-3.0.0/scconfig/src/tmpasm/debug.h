void tmpasm_dump(tmpasm_t *ctx, FILE *f);

