#ifndef REGEX_H
#define REGEX_H

extern const char *bopat[];
extern const char *eopat[];


extern char *re_comp(const char *);
extern int re_exec(const char *);
extern void re_modw(char *);
char *re_subs_dup(char *sub);


#endif /* REGEX_H */
