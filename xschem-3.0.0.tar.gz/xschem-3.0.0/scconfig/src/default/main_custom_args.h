#define MAX_CUSTOM_REQS 32
extern char *custom_reqs[MAX_CUSTOM_REQS];
extern int num_custom_reqs;

int custom_arg(const char *key, const char *value);

