int main_init(void);
int main_process_args(int argc, char *argv[]);
void main_uninit(void);

/* internal */
void init(void);
void uninit(void);
void run_custom_reqs(void);
