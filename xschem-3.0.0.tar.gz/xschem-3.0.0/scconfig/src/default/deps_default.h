void deps_default_init(void);
