int find_gtk3(const char *name, int logdepth, int fatal);

