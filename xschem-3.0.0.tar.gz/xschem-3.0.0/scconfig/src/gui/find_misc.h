int find_libstroke(const char *name, int logdepth, int fatal);
