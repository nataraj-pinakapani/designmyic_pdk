int find_gtk2(const char *name, int logdepth, int fatal);
int find_gtk2gl(const char *name, int logdepth, int fatal);
int find_gtk2_modversion(const char *name, int logdepth, int fatal);
int find_gtk2_key_prefix(const char *name, int logdepth, int fatal);
