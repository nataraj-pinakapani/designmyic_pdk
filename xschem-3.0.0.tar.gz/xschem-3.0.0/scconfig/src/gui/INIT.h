void deps_gui_init();
