int find_cairo(const char *name, int logdepth, int fatal);
int find_cairo_xcb(const char *name, int logdepth, int fatal);

