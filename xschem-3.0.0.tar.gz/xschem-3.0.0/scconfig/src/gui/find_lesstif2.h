int find_lesstif2(const char *name, int logdepth, int fatal);

