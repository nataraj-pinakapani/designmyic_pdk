int find_xinerama(const char *name, int logdepth, int fatal);
int find_xrender(const char *name, int logdepth, int fatal);
int find_xopendisplay(const char *name, int logdepth, int fatal);
int find_xcb(const char *name, int logdepth, int fatal);
int find_xcb_render(const char *name, int logdepth, int fatal);
int find_xgetxcbconnection(const char *name, int logdepth, int fatal);
int find_xpm(const char *name, int logdepth, int fatal);

