int find_gd(const char *name, int logdepth, int fatal);
int find_gdimagepng(const char *name, int logdepth, int fatal);
int find_gdimagegif(const char *name, int logdepth, int fatal);
int find_gdimagejpeg(const char *name, int logdepth, int fatal);
int find_gdimagesetresolution(const char *name, int logdepth, int fatal);

