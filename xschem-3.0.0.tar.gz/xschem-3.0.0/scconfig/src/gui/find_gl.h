int find_gl(const char *name, int logdepth, int fatal);
int find_glu(const char *name, int logdepth, int fatal);
int find_glut(const char *name, int logdepth, int fatal);
int find_gui_wgl(const char *name, int logdepth, int fatal);
